from flask import Flask, render_template, url_for
from flask_mysqldb import MySQL
import json

app = Flask(__name__)
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'new_db'

mysql = MySQL(app)


@app.route('/')
def Home():
    return render_template('home.html')

@app.route('/graph')
def Graph():
    cur = mysql.connection.cursor()
    cur.execute("SELECT CONCAT(Year, Semester) as Time, SUM(stuNo*stuCr*6000) AS Value, SCHOOL_TITLE FROM revenuecsv GROUP BY SCHOOL_TITLE, Time")


    fetchdata = cur.fetchall()
    #r = [dict((cur.description[i][0], value) \
               #for i, value in enumerate(row)) for row in fetchdata]
    cur.close()
    
    
    
    labelsSBE = []
    yySBE = []
    
    yySETS = []

    yySELS = []

    yySLASS = []

    yySPPH = []

    for row in fetchdata:
        if row[2] == 'SBE':
            yySBE.append(float(row[1]))
            labelsSBE.append(row[0])
        elif row[2] == 'SETS':
            yySETS.append(float(row[1]))
        elif row[2] == 'SELS':
            yySELS.append(float(row[1]))
        elif row[2] == 'SLASS':
            yySLASS.append(float(row[1]))
        else:
            yySPPH.append(float(row[1]))

    print(len(yySBE), len(yySETS), len(yySELS), len(yySLASS), len(labelsSBE))
    return render_template('graph.html', labelsSBE = labelsSBE, yySBE = yySBE, yySETS = yySETS, yySELS = yySELS, yySLASS = yySLASS, yySPPH=yySPPH) # data_graph)

@app.route('/graph2')
def GraphSBE():
    cur = mysql.connection.cursor()
    cur.execute("SELECT CONCAT(Year, Semester) as Time, SUM(stuNo*stuCr*6000) AS Value, SCHOOL_TITLE FROM revenuecsv GROUP BY SCHOOL_TITLE, Time")


    fetchdata = cur.fetchall()
    #r = [dict((cur.description[i][0], value) \
               #for i, value in enumerate(row)) for row in fetchdata]
    cur.close()
    
    
    
    labelsSBE = []
    yySBE = []

    for row in fetchdata:
        if row[2] == 'SBE':
            yySBE.append(float(row[1]))
            labelsSBE.append(row[0])

    print(len(yySBE), len(labelsSBE))
    return render_template('graph2.html', labelsSBE = labelsSBE, yySBE = yySBE) # data_graph)

@app.route('/graph3')
def GraphSETS():
    cur = mysql.connection.cursor()
    cur.execute("SELECT CONCAT(Year, Semester) as Time, SUM(stuNo*stuCr*6000) AS Value, SCHOOL_TITLE FROM revenuecsv GROUP BY SCHOOL_TITLE, Time")


    fetchdata = cur.fetchall()
    #r = [dict((cur.description[i][0], value) \
               #for i, value in enumerate(row)) for row in fetchdata]
    cur.close()
    
    
    
    labelsSBE = []
    yySBE = []
    yySETS = []

    for row in fetchdata:
        if row[2] == 'SBE':
            yySBE.append(float(row[1]))
            labelsSBE.append(row[0])
        
        elif row[2] == 'SETS':
            yySETS.append(float(row[1]))

    print(len(yySBE), len(labelsSBE))
    return render_template('graph3.html', labelsSBE = labelsSBE, yySETS = yySETS) # data_graph)

@app.route('/graph4')
def GraphSELS():
    cur = mysql.connection.cursor()
    cur.execute("SELECT CONCAT(Year, Semester) as Time, SUM(stuNo*stuCr*6000) AS Value, SCHOOL_TITLE FROM revenuecsv GROUP BY SCHOOL_TITLE, Time")


    fetchdata = cur.fetchall()
    #r = [dict((cur.description[i][0], value) \
               #for i, value in enumerate(row)) for row in fetchdata]
    cur.close()
    
    
    
    labelsSBE = []
    yySBE = []
    yySELS = []

    for row in fetchdata:
        if row[2] == 'SBE':
            yySBE.append(float(row[1]))
            labelsSBE.append(row[0])
        
        elif row[2] == 'SELS':
            yySELS.append(float(row[1]))

    print(len(yySBE), len(labelsSBE))
    return render_template('graph4.html', labelsSBE = labelsSBE, yySELS = yySELS) # data_graph)

@app.route('/graph5')
def GraphSLASS():
    cur = mysql.connection.cursor()
    cur.execute("SELECT CONCAT(Year, Semester) as Time, SUM(stuNo*stuCr*6000) AS Value, SCHOOL_TITLE FROM revenuecsv GROUP BY SCHOOL_TITLE, Time")


    fetchdata = cur.fetchall()
    #r = [dict((cur.description[i][0], value) \
               #for i, value in enumerate(row)) for row in fetchdata]
    cur.close()
    
    
    
    labelsSBE = []
    yySBE = []
    yySLASS = []

    for row in fetchdata:
        if row[2] == 'SBE':
            yySBE.append(float(row[1]))
            labelsSBE.append(row[0])
        
        elif row[2] == 'SLASS':
            yySLASS.append(float(row[1]))

    print(len(yySBE), len(labelsSBE))
    return render_template('graph5.html', labelsSBE = labelsSBE, yySLASS = yySLASS) # data_graph)

@app.route('/graph6')
def GraphSPPH():
    cur = mysql.connection.cursor()
    cur.execute("SELECT CONCAT(Year, Semester) as Time, SUM(stuNo*stuCr*6000) AS Value, SCHOOL_TITLE FROM revenuecsv GROUP BY SCHOOL_TITLE, Time")


    fetchdata = cur.fetchall()
    #r = [dict((cur.description[i][0], value) \
               #for i, value in enumerate(row)) for row in fetchdata]
    cur.close()
    
    
    
    labelsSBE = []
    yySBE = []
    yySPPH = []

    for row in fetchdata:
        if row[2] == 'SBE':
            yySBE.append(float(row[1]))
            labelsSBE.append(row[0])
        
        elif row[2] == 'SPPH':
            yySPPH.append(float(row[1]))

    print(len(yySBE), len(labelsSBE))
    return render_template('graph6.html', labelsSBE = labelsSBE, yySPPH = yySPPH) # data_graph)

if __name__ == "__main__":
    app.run(debug = True)