from flask import Flask, render_template, url_for
from flask_mysqldb import MySQL
import json

app = Flask(__name__)
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'new_db'

mysql = MySQL(app)


@app.route('/')
def Home():
    return render_template('home.html')

@app.route('/graph')
def Graph():
    cur = mysql.connection.cursor()
    cur.execute("SELECT CONCAT(Year, Semester) as Time, SUM(stuNo*stuCr*6000) AS Value, SCHOOL_TITLE FROM revenuecsv GROUP BY SCHOOL_TITLE, Time")


    fetchdata = cur.fetchall()
    #r = [dict((cur.description[i][0], value) \
               #for i, value in enumerate(row)) for row in fetchdata]
    cur.close()
    
    
    
    labelsSBE = []
    yySBE = []
    
    yySETS = []

    yySELS = []

    yySLASS = []

    yySPPH = []

    for row in fetchdata:
        if row[2] == 'SBE':
            yySBE.append(float(row[1]))
            labelsSBE.append(row[0])
        elif row[2] == 'SETS':
            yySETS.append(float(row[1]))
        elif row[2] == 'SELS':
            yySELS.append(float(row[1]))
        elif row[2] == 'SLASS':
            yySLASS.append(float(row[1]))
        else:
            yySPPH.append(float(row[1]))

    print(len(yySBE), len(yySETS), len(yySELS), len(yySLASS), len(labelsSBE))
    return render_template('graph.html', labelsSBE = labelsSBE, yySBE = yySBE, yySETS = yySETS, yySELS = yySELS, yySLASS = yySLASS, yySPPH=yySPPH) # data_graph)

if __name__ == "__main__":
    app.run(debug = True)